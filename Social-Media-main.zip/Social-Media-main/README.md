
# Social-Media
Social media using php
![Screenshot (120)](https://github.com/ManikantaDaladuri/Social-Media/assets/117551494/704f447c-f1fb-44f8-8889-28c9a2c71973)
![Screenshot (121)](https://github.com/ManikantaDaladuri/Social-Media/assets/117551494/1901de82-b608-498e-82e2-63c4f7e5cb87)
![Screenshot (122)](https://github.com/ManikantaDaladuri/Social-Media/assets/117551494/ce727a52-9498-496a-b98a-fa808d1eca3a)
